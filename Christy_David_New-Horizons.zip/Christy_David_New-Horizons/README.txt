This is a simple program that builds Markov chains off a user inputted "horizon" and draws a new one in real time. 

You start off by running the program and moving your mouse to control the height of the mountain being drawn. When you have drawn a long enough mountain press enter to start the generated line being drawn.

Input:

Enter: Switches between the generative drawing, and the imputed drawing.

R: Takes the generated output and makes it the new state to build the stateTable off of, and starts drawing it again.

Space: This switches between the black and red, "sunset mountain" mode and, the "forest morning" mode. *This mode slows the computer a lot, when looking at don't keep it running in background.
